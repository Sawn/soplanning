<?php

require_once('./base.inc');
require_once(BASE . '/../config.inc');

$smarty = new MySmarty();

require BASE . '/../includes/header.inc';

$smarty->assign('xajax', $xajax->getJavascript("", BASE . "/assets/js/xajax.js"));

$smarty->display('aide/parametres.tpl');

?>